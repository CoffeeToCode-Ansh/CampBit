"""Cross-role access tests for complaints + attendance. Same setup style as test_ownership.py."""
import unittest, sqlite3, datetime as dt
from starlette.testclient import TestClient
import main
from main import app, create_token, hash_password


def mk(conn, login, role, dept=None, hostel=None):
    conn.execute("INSERT INTO users (login_id, name, role, password_hash, dept, hostel) VALUES (?,?,?,?,?,?) "
                 "ON CONFLICT(login_id) DO UPDATE SET role=excluded.role, dept=excluded.dept, hostel=excluded.hostel",
                 (login, login, role, hash_password("Pass123!"), dept, hostel))
    return conn.execute("SELECT id, pw_version FROM users WHERE login_id = ?", (login,)).fetchone()


class TestScope(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        main.init_db()
        cls.c = TestClient(app)
        conn = sqlite3.connect(main.DB_PATH)
        U = {}
        for k, a in {"stu": ("SC-STU", "student", "CSE", "Block A"), "facA": ("SC-FACA", "faculty", "CSE", None),
                     "facB": ("SC-FACB", "faculty", "CSE", None), "facE": ("SC-FACE", "faculty", "ECE", None),
                     "wA": ("SC-WA", "warden", None, "Block A"), "wB": ("SC-WB", "warden", None, "Block B"),
                     "hodC": ("SC-HODC", "hod", "CSE", None), "hodE": ("SC-HODE", "hod", "ECE", None),
                     "prin": ("SC-PRIN", "principal", None, None)}.items():
            U[k] = mk(conn, *a)
        conn.commit()
        cls.h = {k: {"Authorization": "Bearer " + create_token(v[0], v[1])} for k, v in U.items()}
        now = dt.datetime.now(dt.timezone.utc).isoformat()
        cur = conn.execute("INSERT INTO complaints (user_id, login_id, name, category, title, status, is_anonymous, created_at, updated_at) "
                           "VALUES (?, 'SC-STU', 'Anonymous', 'Hostel', 'leaky tap', 'Open', 1, ?, ?)", (U["stu"][0], now, now))
        cls.hostel_cid = cur.lastrowid
        cur = conn.execute("INSERT INTO complaints (user_id, login_id, name, category, title, status, is_anonymous, created_at, updated_at) "
                           "VALUES (?, 'SC-STU', 'SC-STU', 'College', 'projector', 'Open', 0, ?, ?)", (U["stu"][0], now, now))
        cls.college_cid = cur.lastrowid
        conn.commit(); conn.close()

    def get(self, who, url): return self.c.get(url, headers=self.h[who])

    # --- complaints
    def test_wrong_warden_cannot_read(self):
        self.assertEqual(self.get("wB", f"/api/complaints/{self.hostel_cid}").status_code, 404)
    def test_right_warden_reads_but_identity_hidden(self):
        r = self.get("wA", f"/api/complaints/{self.hostel_cid}")
        self.assertEqual(r.status_code, 200); self.assertEqual(r.json()["login_id"], "")
    def test_faculty_cannot_read_any_complaint(self):
        self.assertEqual(self.get("facA", f"/api/complaints/{self.hostel_cid}").status_code, 404)
    def test_hod_scope_is_department_and_category(self):
        self.assertEqual(self.get("hodC", f"/api/complaints/{self.college_cid}").status_code, 200)
        self.assertEqual(self.get("hodE", f"/api/complaints/{self.college_cid}").status_code, 404)
        self.assertEqual(self.get("hodC", f"/api/complaints/{self.hostel_cid}").status_code, 404)
    def test_list_is_filtered(self):
        ids = {x["id"] for x in self.get("wB", "/api/complaints").json()}
        self.assertNotIn(self.hostel_cid, ids)
    def test_wrong_warden_cannot_change_status(self):
        r = self.c.post(f"/api/complaints/{self.hostel_cid}/status", json={"status": "Resolved", "action_note": ""}, headers=self.h["wB"])
        self.assertEqual(r.status_code, 404)
    def test_principal_sees_all(self):
        self.assertEqual(self.get("prin", f"/api/complaints/{self.hostel_cid}").status_code, 200)

    # --- attendance
    def body(self, uuid, sid, dept="CSE", status="present"):
        return {"client_uuid": uuid, "session_id": sid, "dept": dept, "year": "3", "subject": "DBMS", "date": "2026-10-09",
                "records": [{"student_id": "SC-STU", "status": status}]}
    def test_faculty_cannot_mark_other_department(self):
        r = self.c.post("/api/attendance/sync", json=self.body("u1", "sc-s1", "ECE"), headers=self.h["facA"])
        self.assertEqual(r.status_code, 403)
    def test_resync_never_overwrites_and_other_teacher_blocked(self):
        sid = "sc-s2-" + dt.datetime.now().strftime("%H%M%S%f")
        self.assertEqual(self.c.post("/api/attendance/sync", json=self.body("a-" + sid, sid), headers=self.h["facA"]).status_code, 200)
        r = self.c.post("/api/attendance/sync", json=self.body("b-" + sid, sid, status="absent"), headers=self.h["facA"])
        self.assertEqual(r.status_code, 200); self.assertEqual(r.json()["skipped_existing"], 1)
        rec = self.get("facA", f"/api/attendance?session_id={sid}").json()["records"]
        self.assertEqual(rec[0]["status"], "present")
        self.assertEqual(self.c.post("/api/attendance/sync", json=self.body("c-" + sid, sid), headers=self.h["facB"]).status_code, 409)
    def test_read_scope(self):
        sid = "sc-s3-" + dt.datetime.now().strftime("%H%M%S%f")
        self.c.post("/api/attendance/sync", json=self.body("d-" + sid, sid), headers=self.h["facA"])
        self.assertEqual(len(self.get("facB", f"/api/attendance?session_id={sid}").json()["records"]), 0)
        self.assertEqual(len(self.get("hodE", f"/api/attendance?session_id={sid}").json()["records"]), 0)
        self.assertEqual(len(self.get("hodC", f"/api/attendance?session_id={sid}").json()["records"]), 1)
        self.assertEqual(self.get("wA", "/api/attendance").status_code, 403)
    def test_student_without_records_gets_null_not_85(self):
        conn = sqlite3.connect(main.DB_PATH); r = mk(conn, "SC-NEW", "student", "CSE"); conn.commit(); conn.close()
        h = {"Authorization": "Bearer " + create_token(r[0], r[1])}
        self.assertIsNone(self.c.get("/api/attendance", headers=h).json()["percentage"])


if __name__ == "__main__":
    unittest.main()
